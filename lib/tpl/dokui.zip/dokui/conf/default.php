<?php

$conf['width'] = 'auto';
$conf['font-size'] = '1.1em';
$conf['title-color'] = '#009DFF';
$conf['hide-entry-title'] = false;
$conf['footer-text'] = 'Powered by <a href="http://dokuwiki.org/">DokuWiki</a> with a touch of <a href="http://h6e.net/">h6e</a>';
