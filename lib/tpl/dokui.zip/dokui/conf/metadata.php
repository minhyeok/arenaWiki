<?php

$meta['width'] = array('string');
$meta['font-size'] = array('string');
$meta['title-color'] = array('string');
$meta['hide-entry-title'] = array('onoff');
$meta['footer-text'] = array('string');
